'use strict';

import {Observable} from "rxjs";

export const email_admin = /*'nogohbrice@yahoo.fr';//*/'nyassokelydiane@gmail.com';

// eslint-disable-next-line max-len
export const KEY_FOR_PUSH_MESSAGING= 'AAAAla-ImJY:APA91bEaEwecDU3ku6hZ-ODRQb3U3zOa9mjmM_CNRMyg0sJQ9Pyn1riezr7msKn9zOmPPpEeJR_NYpFeueQQz01GjEnJoR-6916uEIam-rTloHIPM0E8ndDlMvk8BUa8DSu9QaPz_ZlR';
export const LOGIN='nogoh:Lionelbrice123@';
export const SERVER = /*'http://bisooft.com/'//'https://polydor-btsh.com/'// */ 'https://bnbsoftservice.com/';
//  export const SERVER = 'http://localhost/'//'https://polydor-btsh.com/'// 'http://testanna.bnbsoftservice.com/';
//export const SERVER_LOCAL = 'http://localhost/'//'http://testanna.bnbsoftservice.com/';
//  export const SERVER_FOR_API = SERVER + 'www/besomewhere/public/api/';
export const SERVER_FOR_API = SERVER + 'besomewhere_api/public/api/';
export const SERVER_URL = SERVER + 'wp-json/';
export const SERVER_FOR_UPLOAD = SERVER + 'uploads/';

export const AUTORIZATION = '';// '?consumer_key=ck_bfe73018b9538cb55598b3ca98b6dd20e9c0c707&consumer_secret=cs_fec53797cfbc4e6bb5e1e049175b0f47acd14596&oauth_consumer_key=ck_bfe73018b9538cb55598b3ca98b6dd20e9c0c707&oauth_token=cs_fec53797cfbc4e6bb5e1e049175b0f47acd14596&oauth_signature_method=HMAC-SHA1&oauth_signature=B%2FAGy8tU7khU%2FhO5hgrNMz7VPHw%3D&oauth_timestamp=1191242096&oauth_nonce=kllo9940pd9333kh';
export let token_chat = 'ewRIgwXeSYyHeb_54Rnf4x:APA91bEp6IFjjOr5tLjQ1uinR-Rbptm27AuQOPE_Xj-bfPXGs1ciLP0FOZaxV3XItLEo_66wwLaux_Urgy7oEMiMXqVuDT_wkZNKu7VzsC3rPXlxBMi3qgzL9upIAFWRHS-R2lvJxXqP';
export let token_for_push;
export const empty_profil = SERVER + 'uploads/app/user.png';
export const per_page = 50;
export const BLOG_ADR = 'http://testanna.bnbsoftservice.com/wp-json/wp/v2/';

export enum TrajetCardStatus{
  ChoosePoint = 0,
  ChooseSchedules = 1,
  ChoosPassenger = 2,
  ChooseItems = 3,
  Ordering = 4,
  Created = 5
}
export enum MealCategory{
  Viennoiserie,
  Sandwich,
  Boisson,
  All
}
export enum ItemCategory {
  Meal,
  Suitcase,
  BabySeats,
}
export const suitcase =   {
  "name": "suitcase",
  "quantity": 0,
  "price": 5,
  "category": ItemCategory.Suitcase,
}
export const babySeats =  [
  {
    "name": "babySeats1",
    "quantity": 0,
    "price": 5,
    "category": ItemCategory.BabySeats,
    "src1":"./assets/img/item/v1.png",
    "src2":"./assets/img/item/v1.png"
  },
  {
    "name": "babySeats2",
    "quantity": 0,
    "price": 5,
    "category": ItemCategory.BabySeats,
    "src1":"./assets/img/item/v1.png",
    "src2":"./assets/img/item/v1.png"
  },
  {
    "name": "babySeats3",
    "quantity": 0,
    "price": 5,
    "category": ItemCategory.BabySeats,
    "src1":"./assets/img/item/v1.png",
    "src2":"./assets/img/item/v1.png"
  },
]

export const meals = [

  {
    "name": "Croissant Beurre",
    "quantity": 0,
    "price": 1.90,
    "category": ItemCategory.Meal,
    "sub_category": 0,
    "src":"./assets/img/item/v1.png"
  },

  {
    "name": "Chausson Pomme",
    "quantity": 0,
    "price": 1.90,
    "category": ItemCategory.Meal,
    "sub_category": 0,
    "src":"./assets/img/item/v2.png"
  },

  {
    "name": "Pain chocolat",
    "quantity": 0,
    "price": 1.90,
    "category": ItemCategory.Meal,
    "sub_category": 0,
    "src":"./assets/img/item/v3.png"
  },



  {
    "name": "Pan Bagnat, Thon Tomate Œuf Olives noir Anchois , Salade",
    "quantity": 0,
    "price": 3.90,
    "category": ItemCategory.Meal,
    "sub_category": 1,
    "src":"./assets/img/item/s1.png"
  },
  {
    "name": "Pain traditionnel , Poulet Mayonnaise, Salade",
    "quantity": 0,
    "price": 3.90,
    "category": ItemCategory.Meal,
    "sub_category": 1,
    "src":"./assets/img/item/s2.png"
  },
  {
    "name": "Pain traditionnel , Poulet  Mayonnaise, Salade",
    "quantity": 0,
    "price": 3.90,
    "category": ItemCategory.Meal,
    "sub_category": 1,
    "src":"./assets/img/item/s3.png"

  },
  {
    "name": "Pan Bagnat, Thon Tomate Œuf Olives noir Anchois , Salade",
    "quantity": 0,
    "price": 3.90,
    "category": ItemCategory.Meal,
    "sub_category": 1,
    "src":"./assets/img/item/s4.png"
  },
  {
    "name": "Pain traditionnel , Rosette Beurre , Cornichons",
    "quantity": 0,
    "price": 3.90,
    "category": ItemCategory.Meal,
    "sub_category": 1,
    "src":"./assets/img/item/s5.jpg"
  },





  {
    "name": "Bouteille Fanta",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/bfanta.jpg"
  },
  {
    "name": "Cannette  Fanta",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/cfanta.png"
  },
  {
    "name": "Lipton Ice Tea",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/clipton.png"
  },
  {
    "name": "Bouteille d'Eau",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/beau.jpg"
  },
  {
    "name": "Cannettte Orangina",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/corangina.png"
  },
  {
    "name": "Cannette Coca",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/ccoca.png"
  },
  {
    "name": "Bouteille Coca",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/bcoca.jpg"
  },
  {
    "name": "Cannette Sprite",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/csprite.png"
  },
  {
    "name": "Bouteille Sprite",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/bsprite.jpg"
  },
  {
    "name": "Cannette Oasis",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/coasis.png"
  },
  {
    "name": "Cannete Schweppes lemon",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/cschweppes.png"
  },
  {
    "name": "Cannette Pepsi",
    "quantity": 0,
    "price": 1,
    "category": ItemCategory.Meal,
    "sub_category": 2,
    "src":"./assets/img/item/cpepsi.png"
  }
]

export const proposedChecklist_cat = [
  {
    id: 1,
    name : 'Document / Identité',
    src : 'passeport-240'
  },
  {
    id: 2,
    name : 'Vêtement et accéssoire',
    src : 'chemise-96'
  },
  {
    id: 3,
    name : 'Moyen de paiement',
    src : 'carte-bancaire-face-arri%C3%A8re-96'
  },
  {
    id: 4,
    name : 'Enfant',
    src : 'enfants-96'
  },
  {
    id: 5,
    name : 'A faire avant de partir',
    src : 'test-partiellement-r%C3%A9ussi-80'
  },
  {
    id: 6,
    name : 'Toilette et Hygiène',
    src : 'shampoo-256'
  },
  {
    id: 7,
    name : 'Animal',
    src : 'group-of-animals-96'
  },
  {
    id: 8,
    name : 'Pharmacie / Santé',
    src : 'pilules-96'
  },
  {
    id: 9,
    name : 'Livre / Lecture',
    src : 'pile-de-livre-96'
  },
  {
    id: 10,
    name : 'Formalité de départ',
    src : 'documents-de-produit-96'
  },
  {
    id: 11,
    name : 'Electonique',
    src : 'casque-audio-96'
  },
]

export const proposedChecklist_items = [
  {
    parent: 1,
    name : 'Carte d’identité ou Passeport',
  },
  {
    parent: 1,
    name : 'Permis de conduire',
  },
  {
    parent: 1,
    name : 'Contacts et attestation d\'assurance et d\'assistance',
  },
  {
    parent: 1,
    name : 'Carte européenne d\'assurance maladie',
  },
  {
    parent: 1,
    name : 'Réservations de transports et d\'hébergements',
  },
  {
    parent: 2,
    name : 'Sous-vêtements',
  },
  {
    parent: 2,
    name : 'Paires de chaussettes',
  },
  {
    parent: 2,
    name : 'Tenues de nuit (pyjama, nuisette, short...)',
  },
  {
    parent: 2,
    name : 'Carnet international de vaccination',
  },
  {
    parent: 2,
    name : 'Coupe-vent imperméable',
  },
  {
    parent: 2,
    name : 'T-shirts manches longues',
  },
  {
    parent: 2,
    name : 'T-shirts manches courtes',
  },
  {
    parent: 2,
    name : 'Pantalons Jean',
  },
  {
    parent: 2,
    name : 'Pantalons jogging',
  },
  {
    parent: 2,
    name : 'Pantalons Randonné',
  },
]
// {
//   id:4,
//   name : 'Bateau à voile',
//   src :'sailboat'
// },
export const transport_mode = [
  {
    id:1,
    name : 'Avion',
    src :'plane'
  },
  {
    id:2,
    name : 'Bus',
    src :'bus'
  },
  {
    id:3,
    name : 'Bateau',
    src :'boat'
  },
  {
    id:5,
    name : 'Marche',
    src :'walk'
  },
  {
    id:6,
    name : 'Vélo',
    src :'bicycle'
  },
  {
    id:7,
    name : 'Train',
    src :'train'
  },
  {
    id:8,
    name : 'Moto',
    src :'scooter'
  },
  {
    id:9,
    name : 'Voiture',
    src :'taxi'
  },

]
export let listString  = '            <li style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; list-style-type: none; list-style-position: outside; display: flex; align-items: center; padding: 2px;">'+
'                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="1em" height="1em" style="font-size: 23px;">'+
'                    <g>'+
'                        <path fill="none" d="M0 0h24v24H0z"/>'+
'                        <path d="M4 6.143v12.824l5.065-2.17 6 3L20 17.68V4.857l1.303-.558a.5.5 0 0 1 .697.46V19l-7 3-6-3-6.303 2.701a.5.5 0 0 1-.697-.46V7l2-.857zm12.243 5.1L12 15.485l-4.243-4.242a6 6 0 1 1 8.486 0zM12 12.657l2.828-2.829a4 4 0 1 0-5.656 0L12 12.657z"/>'+
'                    </g>'+
'                </svg>'+
'                <p style="margin-bottom: 0; padding-left: 7px;">{$text}</p> '+
'            </li>'

export let divMap = '<div style="z-index: 2, width: auto; display: inline-block; flex-direction: column; justify-content: center; align-items: center;">'+
'    <div style="width: 100%; background-color: #1b7eba; color: #ffffff; font-size: 18px; border-radius: 5px; border-top-color: #d67171;">'+
'        <p style="margin-bottom: 0; padding-left: 10px; padding-bottom: 5px; padding-top: 5px; font-size: 18px; font-weight: 900; border-bottom: 1px solid #fff7f7;">Points au allentours</p>'+
'        <ul style="padding: 5px; margin-bottom: 0;">'+ '{$data}'+

'        </ul>'+
'    </div>'+
'</div>';

// export let divMap = '<div style="width: auto; display: inline-block; flex-direction: column; justify-content: center; align-items: center;">'+
// '    <div style="width: 100%; background-color: #1b7eba; color: #ffffff; font-size: 18px; border-radius: 5px; border-top-color: #d67171;">'+
// '        <p style="margin-bottom: 0; padding-left: 10px; padding-bottom: 5px; padding-top: 5px; font-size: 18px; font-weight: 900; border-bottom: 1px solid #fff7f7;">Points au allentours</p>'+
// '        <ul style="padding: 5px; margin-bottom: 0;">'+
// '            <li style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; list-style-type: none; list-style-position: outside; display: flex; align-items: center; padding: 2px;">'+
// '                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="1em" height="1em" style="font-size: 23px;">'+
// '                    <g>'+
// '                        <path fill="none" d="M0 0h24v24H0z"/>'+
// '                        <path d="M4 6.143v12.824l5.065-2.17 6 3L20 17.68V4.857l1.303-.558a.5.5 0 0 1 .697.46V19l-7 3-6-3-6.303 2.701a.5.5 0 0 1-.697-.46V7l2-.857zm12.243 5.1L12 15.485l-4.243-4.242a6 6 0 1 1 8.486 0zM12 12.657l2.828-2.829a4 4 0 1 0-5.656 0L12 12.657z"/>'+
// '                    </g>'+
// '                </svg>'+
// '                <p style="margin-bottom: 0; padding-left: 7px;">Restaurant la fleuri</p> '+
// '            </li>'+
// '            <li style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; list-style-type: none; list-style-position: outside; display: flex; align-items: center; padding: 2px;">'+
// '                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="1em" height="1em" style="font-size: 23px;">'+
// '                    <g>'+
// '                        <path fill="none" d="M0 0h24v24H0z"/>'+
// '                        <path d="M4 6.143v12.824l5.065-2.17 6 3L20 17.68V4.857l1.303-.558a.5.5 0 0 1 .697.46V19l-7 3-6-3-6.303 2.701a.5.5 0 0 1-.697-.46V7l2-.857zm12.243 5.1L12 15.485l-4.243-4.242a6 6 0 1 1 8.486 0zM12 12.657l2.828-2.829a4 4 0 1 0-5.656 0L12 12.657z"/>'+
// '                    </g>'+
// '                </svg>'+
// '                <p style="margin-bottom: 0; padding-left: 7px;">Restaurant la Sterline</p> '+
// '            </li>'+
// '            <li style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; list-style-type: none; list-style-position: outside; display: flex; align-items: center; padding: 2px;">'+
// '                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="1em" height="1em" style="font-size: 23px;">'+
// '                    <g>'+
// '                        <path fill="none" d="M0 0h24v24H0z"/>'+
// '                        <path d="M4 6.143v12.824l5.065-2.17 6 3L20 17.68V4.857l1.303-.558a.5.5 0 0 1 .697.46V19l-7 3-6-3-6.303 2.701a.5.5 0 0 1-.697-.46V7l2-.857zm12.243 5.1L12 15.485l-4.243-4.242a6 6 0 1 1 8.486 0zM12 12.657l2.828-2.829a4 4 0 1 0-5.656 0L12 12.657z"/>'+
// '                    </g>'+
// '                </svg>'+
// '                <p style="margin-bottom: 0; padding-left: 7px;">Discothèque de madra</p> '+
// '            </li>'+
// '        </ul>'+
// '    </div>'+
// '    <div style="display: flex; justify-content: center;">'+
// '        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="3em" height="3em" fill="currentColor" style="padding-top: 5px; color: #ff0000;">'+
// '            <g>'+
// '                <path fill="none" d="M0 0h24v24H0z"/>'+
// '                <path d="M12 20.9l4.95-4.95a7 7 0 1 0-9.9 0L12 20.9zm0 2.828l-6.364-6.364a9 9 0 1 1 12.728 0L12 23.728zM12 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/>'+
// '            </g>'+
// '        </svg>'+
// '    </div>'+
// '</div>';



export const headers = {
  'Content-Type': "application/json	",
  Authorization: 'Basic Ym5ic29mdGIxODpCbmJzb2Z0c2VydmljZTIwMjE='
};

export  enum UserType {
  Admin,
  Vendor,
  Deliverer,
  Buyer,
}
export enum CautionType {
  Order,
  Product,
  USERT_REPORT,
  None
}
export enum NotificationType {
  Order,
  Product,
  OrderDeliverer,
  Chat,
  Account
}
export enum StatusOrder {
  OnHold = 'on-hold',
  Failed = "failed",
  Processing = 'processing',
  Pending = 'pending',
  Completed = 'completed',
  Refunding = 'refunding',
  Refunded = 'refunded',
  Cancel = 'cancelled'
}


export let toast;
export let notifications = [];
// export const version= Observable <any> = ;
export const comissionBuyer = 0.2 ;
export const comissionSeller = 0.15 ;
export const comissionDeliverer = 0.10 ;





